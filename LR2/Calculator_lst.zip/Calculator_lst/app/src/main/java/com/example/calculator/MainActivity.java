package com.example.calculator;

import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    private EditText num_1, num_2;
    private TextView res,textplus,textminus,textequal,textdiv,textmult;
    private Button plus, mult, minus, clear, div;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // объявление объектов
        res = findViewById(R.id.res);
        num_1 = findViewById(R.id.num_1);
        num_2 = findViewById(R.id.num_2);
        plus = findViewById(R.id.plus);
        mult = findViewById(R.id.mult);
        clear = findViewById(R.id.clear);
        div = findViewById(R.id.div);
        minus = findViewById(R.id.minus);
        textplus = findViewById(R.id.textplus);
        textequal = findViewById(R.id.textequal);
        textdiv = findViewById(R.id.textdiv);
        textmult = findViewById(R.id.textmult);
        textminus = findViewById(R.id.textminus);


        // Видимость операторов
        textplus.setVisibility(INVISIBLE);
        textminus.setVisibility(INVISIBLE);
        textdiv.setVisibility(INVISIBLE);
        textmult.setVisibility(INVISIBLE);

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textplus.setVisibility(VISIBLE);
                textminus.setVisibility(INVISIBLE);
                textdiv.setVisibility(INVISIBLE);
                textmult.setVisibility(INVISIBLE);
                float num_1_us = Float.parseFloat(num_1.getText().toString());
                float num_2_us = Float.parseFloat(num_2.getText().toString());
                float res_us = num_1_us + num_2_us;
                res.setText(String.valueOf(res_us));
                                        }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textplus.setVisibility(INVISIBLE);
                textminus.setVisibility(VISIBLE);
                textdiv.setVisibility(INVISIBLE);
                textmult.setVisibility(INVISIBLE);
                float num_1_us = Float.parseFloat(num_1.getText().toString());
                float num_2_us = Float.parseFloat(num_2.getText().toString());
                float res_us = num_1_us - num_2_us;
                res.setText(String.valueOf(res_us));
                                        }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textplus.setVisibility(INVISIBLE);
                textminus.setVisibility(INVISIBLE);
                textdiv.setVisibility(VISIBLE);
                textmult.setVisibility(INVISIBLE);
                float num_1_us = Float.parseFloat(num_1.getText().toString());
                float num_2_us = Float.parseFloat(num_2.getText().toString());
                if (num_2_us == 0){
                    Toast.makeText(MainActivity.this, "Ошибка, делить на ноль нельзя", Toast.LENGTH_SHORT).show();
                    res.setText(String.valueOf("Nan"));
                    return;
                }
                float res_us = num_1_us / num_2_us;
                res.setText(String.valueOf(res_us));

                                        }
        });

        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textplus.setVisibility(INVISIBLE);
                textminus.setVisibility(INVISIBLE);
                textdiv.setVisibility(INVISIBLE);
                textmult.setVisibility(VISIBLE);
                float num_1_us = Float.parseFloat(num_1.getText().toString());
                float num_2_us = Float.parseFloat(num_2.getText().toString());
                float res_us = num_1_us * num_2_us;
                res.setText(String.valueOf(res_us));

                                        }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textplus.setVisibility(INVISIBLE);
                textminus.setVisibility(INVISIBLE);
                textdiv.setVisibility(INVISIBLE);
                textmult.setVisibility(INVISIBLE);
                num_1.setText("");
                num_2.setText("");
                res.setText("");

                Toast.makeText(MainActivity.this,"Все поля очищены",Toast.LENGTH_SHORT).show();

            }
        });

    }
}
