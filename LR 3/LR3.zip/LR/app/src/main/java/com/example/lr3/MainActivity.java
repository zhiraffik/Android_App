package com.example.lr3;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {


    private Button btn1,btn2,btn3,btn_test;
    private TextView name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn_test=findViewById(R.id.btn_test);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Кнопка номер 1 нажата",Toast.LENGTH_SHORT).show();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Кнопка 2 нажата",Toast.LENGTH_LONG).show();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Кнопка 3")
                .setIcon(R.drawable.test_icon)
                .setMessage("Вы хотите продолжить?")
                .setPositiveButton("Да", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        btn1.setTextColor(Color.RED);
                        btn2.setTextColor(Color.RED);
                        btn3.setTextColor(Color.RED);
                    }
                })
                .setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this,"Диалог закрыт", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                })
                        .create()
                        .show();
            }
        });


        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String[] animals = {"Корова","Лев","Лошадь","Волк","Кролик"};

                final boolean[] checkItems = {false,false,false,false,false};

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Выберите травоядных животных")
                        .setIcon(R.drawable.test_icon)
                        .setMultiChoiceItems(animals, checkItems, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                                checkItems [which] = isChecked;
                            }
                        })
                        .setPositiveButton("Проверить", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                boolean correctCow = checkItems[0]; // +
                                boolean correctHorse = checkItems[2]; // +
                                boolean correctRabbit = checkItems[4]; // +
                                boolean correctWolf  = checkItems[3]; // -
                                boolean correctLion = checkItems[1]; // -

                                if (correctCow && correctHorse && correctRabbit && !correctLion && !correctWolf){
                                    // ???
                                    Toast.makeText(MainActivity.this, "Все ответы Правильные!", Toast.LENGTH_SHORT).show();
                                }
                                else {
                                    btn1.setVisibility(View.INVISIBLE);
                                    btn2.setVisibility(View.INVISIBLE);
                                    btn3.setVisibility(View.INVISIBLE);
                                    btn_test.setVisibility(View.INVISIBLE);
                                    Toast.makeText(MainActivity.this, "Неверно, кнопки скрыты", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Отмена", Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }
                        })
                        .create()
                        .show();
            }
        });

    }
}